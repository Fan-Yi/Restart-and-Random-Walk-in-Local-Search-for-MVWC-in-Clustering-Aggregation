if [ $# -lt 2 ] ; then
	echo "Usage $(basename $0) seed_lower_bound seed_upper_bound"
	exit
fi

min=$1
max=$2

i=$min

while [ $i -le $max ]
do
	./myLSCC Pendig.txt $i 1
	#./myLSCC 8D5K.txt $i 1
	#./myLSCC Iris.txt $i 1
	i=$[$i+1]
done
