#ifndef CONSTANTS_H
#define CONSTANTS_H
const int TRY_STEP = 100;
const int PRIME_NUM = 1000000007; //10^9+7
//const long double EPS = 0.000000000001;//10^-12
const long double EPS = 0.0001;//10^-4
#endif
