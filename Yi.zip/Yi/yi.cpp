#include <iostream>
#include "localSearch.h"
#include "mex.h"

using namespace std;

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	int *adjacency_list = (int *)mxGetPr(prhs[0]);
    int mrows = mxGetM(prhs[0]);  
	long double *weight_list = (long double *)mxGetPr(prhs[1]);
	int v_num = (int)mxGetScalar(prhs[2]);
	int e_num = (int)mxGetScalar(prhs[3]);
	int seed = (int)mxGetScalar(prhs[4]);
	int time_limit = (int)mxGetScalar(prhs[5]);
	
	int **adjacent_matrix = new int*[v_num + 1];
    for(int i = 0; i <= v_num; i++)  
		adjacent_matrix[i] = new int[v_num + 1];
	for (int i = 0; i <= v_num; i++)
    {
      for (int j = 0; j <= v_num; j++)
      {
		  adjacent_matrix[j][i] = adjacency_list[i * (v_num+1) + j];
      }
    }

	srand(seed);
	StochasticLocalSearch mySLS(adjacent_matrix, weight_list, v_num, e_num, time_limit);

	mySLS.clique_sls();

	int ncols;           /* size of matrix */
	int *outMatrix;      /* output matrix */

	/* call the computational routine */
	ncols = mySLS.get_best_weighted_clique_size();

	/* create the output matrix */
	plhs[0] = mxCreateNumericMatrix(1,ncols,mxINT32_CLASS,mxREAL);

 	/* get a pointer to the real data in the output matrix */
 	outMatrix = (int *)mxGetData(plhs[0]);
 
 	/* call the computational routine */
 	mySLS.get_best_weighted_clique(outMatrix);
 
// 	//return 0;

}

