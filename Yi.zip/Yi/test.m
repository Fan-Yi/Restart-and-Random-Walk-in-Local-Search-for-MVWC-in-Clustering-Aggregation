clear;

adjacenct_matrix = [0,0,0,0;0,0,1,1;0,1,0,1;0,1,1,0];

weight_list = [0,1,2,3];

v_num = 3;
e_num = 3;
seed = 1;
time_limit = 10000;

a = yi(int32(adjacenct_matrix(:)), weight_list, v_num, e_num, seed, time_limit);