#ifndef LINKED_PARTITIONS_H
#define LINKED_PARTITIONS_H

#include <stdlib.h>
#include <iostream>
#include <string.h>

#include "hugeInt.h"

//#define debug_mode

using namespace std;

class Linked_partitions
{
private:
	class SwapVertexNode{
	public:
		int swapVertex;
		SwapVertexNode *prev;
		SwapVertexNode *next;
	};

	SwapVertexNode *swapVertices;
	SwapVertexNode *scoreBucketHeads;
	SwapVertexNode *scoreBucketTails;
	SwapVertexNode *zeroScoreHeadPtr;
	SwapVertexNode *zeroScoreTailPtr;
	int bucketNum;
	int swapVertexNum;
	int total_bucket_size;
	int *inScoreBuckets;
	SwapVertexNode *maxScoreBucketPtr;

void enlargeBucketNum()
{
	int max_score = maxScoreBucketPtr - zeroScoreHeadPtr;

	SwapVertexNode *new_heads, *new_tails;
	bucketNum = (bucketNum << 1) - 1;
	try
	{
		new_heads = new SwapVertexNode[bucketNum];
	}
	catch(std::bad_alloc& ba)
	{
		cout << "memory unavailable, when allocating space for NEW scoreBucketHeads" << endl;
		cerr << "bad_alloc caught: " << ba.what() << endl;
	}
	try
	{
		new_tails = new SwapVertexNode[bucketNum];
	}
	catch(std::bad_alloc& ba)
	{
		cout << "memory unavailable, when allocating space for NEW scoreBucketTails" << endl;
		cerr << "bad_alloc caught: " << ba.what() << endl;
	}
#ifdef debug_mode
cout << "new bucket memory allocated successfully" << endl;
#endif
	SwapVertexNode *head_p = scoreBucketHeads, *tail_p = scoreBucketTails;
	SwapVertexNode *new_head_p = new_heads, *new_tail_p = new_tails;
	SwapVertexNode *new_head_p_end = new_heads + bucketNum;

	SwapVertexNode *q1 = new_heads + (bucketNum >> 2);
	SwapVertexNode *q2 = q1 + (bucketNum >> 1);

	while(new_head_p < q1)
	{
		new_head_p->prev = NULL;
		new_tail_p->next = NULL;
		new_head_p->next = new_tail_p;//no nodes
		new_tail_p->prev = new_head_p;//no nodes
		new_head_p++; new_tail_p++;
	}
//cout << "1/4 of the buckets have been initialized successfully" << endl;
	while(new_head_p <= q2)
	{
		new_head_p->prev = NULL;
		new_tail_p->next = NULL;
		if(head_p->next->next)
		{
			new_head_p->next = head_p->next;
			new_head_p->next->prev = new_head_p;
			new_tail_p->prev = tail_p->prev;
			new_tail_p->prev->next = new_tail_p;
		}
		else
		{
			new_head_p->next = new_tail_p;//no nodes
			new_tail_p->prev = new_head_p;//no nodes			
		}
		head_p++; tail_p++;
		new_head_p++; new_tail_p++;
	}
//cout << "3/4 of the buckets have been initialized successfully" << endl;
	while(new_head_p < new_head_p_end)
	{
		new_head_p->prev = NULL;
		new_tail_p->next = NULL;
		new_head_p->next = new_tail_p;//no nodes
		new_tail_p->prev = new_head_p;//no nodes
		new_head_p++; new_tail_p++;
	}
//cout << "all of the buckets have been initialized successfully" << endl;
	delete[] scoreBucketHeads;
	delete[] scoreBucketTails;
	scoreBucketHeads = new_heads;
	scoreBucketTails = new_tails;
//cout << "scoreBucketHeads and scoreBucketTails have pointed to the new allocated space" << endl;
	zeroScoreHeadPtr = scoreBucketHeads + (bucketNum >> 1);
	zeroScoreTailPtr = scoreBucketTails + (bucketNum >> 1);

	maxScoreBucketPtr = zeroScoreHeadPtr + max_score;
}

public:
Linked_partitions(int v_num, int bNum)
{
#ifdef debug_mode
cout << "size of int: " << sizeof(int) << endl;
cout << "size of SwapVertexNode*: " << sizeof(SwapVertexNode*) << endl;
cout << "size of SwapVertexNode: " << sizeof(SwapVertexNode) << endl;
#endif
	swapVertexNum = v_num;
	try
	{
		swapVertices = new SwapVertexNode[swapVertexNum + 2];
	}
	catch(std::bad_alloc& ba)
	{
		cout << "memory unavailable, when allocating space for swapVertices" << endl;
		cerr << "bad_alloc caught: " << ba.what() << endl;
	}
	SwapVertexNode *p = swapVertices + 1;
	SwapVertexNode *p_end = swapVertices + swapVertexNum;
	int name = 1;
	while(p <= p_end)//initialized to be 1 to var_n
	{
		p->swapVertex = name;
		p->prev = NULL;//not in
		p->next = NULL;//not in
		p++; name++;
	}
	try
	{
		inScoreBuckets = new int[swapVertexNum + 2];
	}
	catch(std::bad_alloc& ba)
	{
		cout << "memory unavailable, when allocating space for inScoreBuckets" << endl;
		cerr << "bad_alloc caught: " << ba.what() << endl;
	}

	memset(inScoreBuckets, 0, sizeof(int) * (swapVertexNum + 2));//not in
/////////////////////////////////////////////////////////////////////////////////////////////
	bucketNum = bNum;
	//bucketNum = computeRequiredBucketNum();
#ifdef debug_mode
//cout << "the number of buckets needed is " << bucketNum << endl;
#endif
	try
	{
		scoreBucketHeads = new SwapVertexNode[bucketNum];
	}
	catch(std::bad_alloc& ba)
	{
		cout << "memory unavailable, when allocating space for scoreBucketHeads" << endl;
		cerr << "bad_alloc caught: " << ba.what() << endl;
	}

	try
	{
		scoreBucketTails = new SwapVertexNode[bucketNum];
	}
	catch(std::bad_alloc& ba)
	{
		cout << "memory unavailable, when allocating space for scoreBucketTails" << endl;
		cerr << "bad_alloc caught: " << ba.what() << endl;
	}
	
	SwapVertexNode *head_p = scoreBucketHeads;
	SwapVertexNode *tail_p = scoreBucketTails;
	SwapVertexNode *head_p_end = scoreBucketHeads + bucketNum;
	while(head_p < head_p_end)
	{
		head_p->swapVertex = 0;
		head_p->prev = NULL;
		head_p->next = tail_p;//no nodes
		tail_p->swapVertex = 0;
		tail_p->next = NULL;
		tail_p->prev = head_p;//no nodes
		head_p++; 
		tail_p++;
	}

	zeroScoreHeadPtr = scoreBucketHeads + bucketNum / 2;
	zeroScoreTailPtr = scoreBucketTails + bucketNum / 2;

	total_bucket_size = 0;//no nodes
	maxScoreBucketPtr = scoreBucketHeads;
}

~Linked_partitions()
{
	delete[] swapVertices;
//cout << "2: " << scoreBucketHeads << endl;
	delete[] scoreBucketHeads;
//cout << "3: " << scoreBucketTails << endl;
	delete[] scoreBucketTails;
//cout << "4: " << inScoreBuckets << endl;
	delete[] inScoreBuckets;

	swapVertexNum = 0;
	bucketNum = 0;
	total_bucket_size = 0;	
}

void clear()
{
	SwapVertexNode *p = swapVertices + 1;
	SwapVertexNode *p_end = swapVertices + swapVertexNum;
	while(p <= p_end)//initialized to be 1 to var_n
	{
		p->prev = NULL;//not in
		p->next = NULL;//not in
		p++;
	}

	memset(inScoreBuckets, 0, sizeof(int) * (swapVertexNum + 2));//not in

	SwapVertexNode *head_p = scoreBucketHeads;
	SwapVertexNode *tail_p = scoreBucketTails;
	SwapVertexNode *head_p_end = scoreBucketHeads + bucketNum;
	while(head_p < head_p_end)
	{
		head_p->prev = NULL;
		head_p->next = tail_p;//no nodes
		tail_p->next = NULL;
		tail_p->prev = head_p;//no nodes
		head_p++; 
		tail_p++;
	}

	total_bucket_size = 0;		

	maxScoreBucketPtr = scoreBucketHeads;
}

void insertSwapVertexNode(int swapVertex, int *score)
{
#ifdef debug_mode
if(inScoreBuckets[swapVertex] == 1)
{
	cout << "try to insert an inside variable" << endl;
	exit(1);
}
/*
if(v < 1 || v > swapVertexNum)
{
	cout << "try to insert an invalid variable: " << v << endl;
	exit(1);
}
*/
#endif
	while(score[swapVertex] > (bucketNum >> 1) || score[swapVertex] < -(bucketNum >> 1))
	{
#ifdef debug_mode
cout << "the score of var " << v << " is " << score[v] << endl;
cout << "the bucket bound is +/-" << bucketNum / 2 << endl;
cout << "exceeds the bucket bound, should enlarge bucketNum" << endl;
#endif
		enlargeBucketNum();
	}
	SwapVertexNode *bucket_tail_p = zeroScoreTailPtr + score[swapVertex];
	SwapVertexNode *swapVertex_p = swapVertices + swapVertex;
	SwapVertexNode *last_p = bucket_tail_p -> prev;
	last_p -> next = swapVertex_p;
	swapVertex_p -> prev = last_p;
#ifdef debug_mode
//cout << "last_p ok" << endl;
#endif
	bucket_tail_p -> prev = swapVertex_p;
	swapVertex_p -> next = bucket_tail_p;
#ifdef debug_mode
//cout << "bucket_tail_p ok" << endl;
#endif
	inScoreBuckets[swapVertex] = 1;
	total_bucket_size++;
#ifdef debug_mode
//cout << "bucketNum: " << bucketNum << endl;
//cout << "scoreBucketHeads: " << scoreBucketHeads << endl;
//cout << "zeroScoreHeadPtr: " << zeroScoreHeadPtr << endl;
//cout << "maxScoreBucketPtr - scoreBucketHeads: " << maxScoreBucketPtr - scoreBucketHeads << endl;
//cout << "maxScoreBucketPtr - zeroScoreHeadPtr: " << maxScoreBucketPtr - zeroScoreHeadPtr << endl;
//cout << "score[v]: " << score[v] << endl;
#endif
	if(maxScoreBucketPtr < zeroScoreHeadPtr + score[swapVertex])
	{
#ifdef debug_mode
		//cout << "maxScoreBucketPtr updated to be " << zeroScoreHeadPtr + score[v] << ", with score " << score[v] << endl;
#endif
		maxScoreBucketPtr = zeroScoreHeadPtr + score[swapVertex];
	}

#ifdef debug_mode
//showBuckets();
#endif
}

void deleteSwapVertexNode(int swapVertex)
{
#ifdef debug_mode
if(inScoreBuckets[swapVertex] == 0)
{
	cout << "try to delete an outside variable" << endl;
	exit(1);
}
/*
if(v < 1 || v > swapVertexNum)
{
	cout << "try to delete an invalid variable: " << v << endl;
	exit(1);
}
*/
#endif
	SwapVertexNode *q = swapVertices + swapVertex;
	SwapVertexNode *p = q -> prev;
	SwapVertexNode *r = q -> next;
	r -> prev = p;
	p -> next = r;
	inScoreBuckets[swapVertex] = 0;
	total_bucket_size--;
	if(!total_bucket_size)
	{
		maxScoreBucketPtr = scoreBucketHeads;
		return;
	}
	while(!(maxScoreBucketPtr->next->next)) 
		maxScoreBucketPtr--;
}

int bestGreedySwapVertex(int score_bound, int *confChange, HugeInt * last_changed_time)
//obtain a vertex v whose configuration has changed with the greatest score, breaking ties in favor of the oldest one
//, and the resp. score is not smaller than score_bound
//if no such vertices exist, return 0
{
#ifdef debug_mode
cout << "begin to do best-pick" << endl;
#endif
//cout << 1.1 << endl;
//cout << "score_bound: " << score_bound << endl;
	SwapVertexNode *p = maxScoreBucketPtr;
	int best_swapVertex = 0;
	int v;
	do{
		if(p - zeroScoreHeadPtr < score_bound) return 0;
		SwapVertexNode *q = p->next;
//cout << 1.01 << endl;
//cout << "score: " << p - zeroScoreHeadPtr << endl;
		while(q->next)
		{
			v = q -> swapVertex;
//cout << "v: " << v << ", score: " << p - zeroScoreHeadPtr << endl;
			q = q -> next;
			if(confChange[v] != 0)
			{
				best_swapVertex = v;
				break;
			}
		}
//cout << 1.02 << endl;
		while(q -> next)
		{
			v = q -> swapVertex;
//cout << "obtaining " << v << endl;
//getchar();
			if(confChange[v] == 1)
			{
				if(last_changed_time[best_swapVertex] > last_changed_time[v])
					best_swapVertex = v;
			}
			q = q -> next;
		}
//cout << 1.03 << endl;
		if(p == scoreBucketHeads) break;
		p--;
	}while(best_swapVertex == 0);
//cout << 1.2 << endl;
	return best_swapVertex;
}

int isCandSwapVertex(int swapVertex)
{
	return inScoreBuckets[swapVertex];
}

int existCandSwapVertices()
{
	return total_bucket_size;
}

int check_buckets(int *score)
{
	int verified_size = 0;
//cout << "bucketNum: " << bucketNum << endl;
cout << "totalBucketSize: " << total_bucket_size << endl;
cout << "max_score: " << maxScoreBucketPtr - zeroScoreHeadPtr << endl;
//cout << "zero_score is located: " << zeroScoreHeadPtr - scoreBucketHeads << endl;
	for(int i = 0; i < bucketNum; i++)
	{
		SwapVertexNode *q1 = scoreBucketHeads + i;
		SwapVertexNode *q2 = scoreBucketTails + i;
		
		if(q1->prev != NULL)
		{
			cout << "the " << i << "-th bucket, head node contains illegal prev-pointer values" << endl;
			return 0;
		}
		if(q2->next != NULL)
		{
			cout << "the " << i << "-th bucket, tail node contains illegal next-pointer values" << endl;
			return 0;
		}
		SwapVertexNode *p = (scoreBucketHeads + i) -> next;
		while(p -> next)
		{
//cout << "found " << p->swapVertex << endl;
			if(inScoreBuckets[p->swapVertex] != 1)
			{
				cout << "inScoreBuckets property incorrect" << endl;
				return 0;
			}
			if(score[p->swapVertex] != -bucketNum/2 + i)
			{
				cout << "score property incorrect" << endl;
				return 0;
			}
			verified_size++;
			p = p -> next;
		}
	}
	if(verified_size != total_bucket_size)
	{
		cout << "verified_size: " << verified_size << endl;
		cout << "total_bucket_size: " << total_bucket_size << endl;
		cout << "bucket size incorrect" << endl;
		return 0;
	}
	return 1;
}
};
#endif
