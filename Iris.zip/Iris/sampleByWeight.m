function [sampleIdx] = sampleByWeight(weightList,sampleNum)

wList = weightList;

sampleIdx = zeros(sampleNum,1);

for i = 1:sampleNum
    wList = wList./sum(wList);
    csList = cumsum(wList);
    thisIdx = sum(csList<rand)+1;
    sampleIdx(i) = thisIdx;
    wList(thisIdx) = 0;
end
