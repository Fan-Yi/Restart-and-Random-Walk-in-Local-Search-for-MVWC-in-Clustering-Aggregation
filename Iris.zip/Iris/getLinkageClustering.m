clear;

load('data.mat');

kList = 2:10;
kNum = numel(kList);

algorithmNum = 1;

clusterNum = sum(kList) * algorithmNum;
clusteringNum = kNum * algorithmNum;
dataNum = numel(label);

lkClusterPts = cell(clusterNum,1);
lkClusterSLE = zeros(clusterNum,1);
lkClustering = zeros(dataNum,clusteringNum);
lkClusteringSLE = zeros(clusteringNum,1);
lkLedger = zeros(clusterNum,2);

clusterIdx = 0;
clusteringIdx = 0;

% complete linkage
Z = linkage(data,'complete');
for i = 1:kNum
    k = kList(i);    
    IDX = cluster(Z,'maxclust',k);
    SLE = silhouette(data,IDX);  
    clusteringIdx = clusteringIdx + 1;
    lkClustering(:,clusteringIdx) = IDX;
    lkClusteringSLE(clusteringIdx,1) = sum(SLE);
    for j = 1:k
        clusterIdx = clusterIdx + 1;
        thisClusterPts = find(IDX == j);
        lkClusterPts{clusterIdx} = thisClusterPts;
        thisSLE = SLE(thisClusterPts);
        lkClusterSLE(clusterIdx) = sum(thisSLE);
        lkLedger(clusterIdx,1) = clusteringIdx;
        lkLedger(clusterIdx,2) = 1;
    end
end

% % average linkage
% Z = linkage(data,'average');
% for i = 1:kNum
%     k = kList(i);    
%     IDX = cluster(Z,'maxclust',k);
%     SLE = silhouette(data,IDX);  
%     clusteringIdx = clusteringIdx + 1;
%     lkClustering(:,clusteringIdx) = IDX;
%     lkClusteringSLE(clusteringIdx,1) = sum(SLE);
%     for j = 1:k
%         clusterIdx = clusterIdx + 1;
%         thisClusterPts = find(IDX == j);
%         lkClusterPts{clusterIdx} = thisClusterPts;
%         thisSLE = SLE(thisClusterPts);
%         lkClusterSLE(clusterIdx) = sum(thisSLE);
%         lkLedger(clusterIdx,1) = clusteringIdx;
%         lkLedger(clusterIdx,2) = 2;
%     end
% end
% 
% % ward's
% Z = linkage(data,'ward');
% for i = 1:kNum
%     k = kList(i);    
%     IDX = cluster(Z,'maxclust',k);
%     SLE = silhouette(data,IDX);  
%     clusteringIdx = clusteringIdx + 1;
%     lkClustering(:,clusteringIdx) = IDX;
%     lkClusteringSLE(clusteringIdx,1) = sum(SLE);
%     for j = 1:k
%         clusterIdx = clusterIdx + 1;
%         thisClusterPts = find(IDX == j);
%         lkClusterPts{clusterIdx} = thisClusterPts;
%         thisSLE = SLE(thisClusterPts);
%         lkClusterSLE(clusterIdx) = sum(thisSLE);
%         lkLedger(clusterIdx,1) = clusteringIdx;
%         lkLedger(clusterIdx,2) = 2;
%     end
% end

save('LinkageClustering.mat','lkClusterPts','lkClusterSLE','lkClustering',...
    'lkClusteringSLE','lkLedger','kList');