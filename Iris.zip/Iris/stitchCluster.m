function [clusterLabel,Silhouette] = stitchCluster(clusterPts,data)

[dataNum,attributeNum] = size(data);
clusterNum = numel(clusterPts);

dataInfo = zeros(dataNum,2);
clusterCenter = zeros(clusterNum,attributeNum);
clusterLabel = zeros(dataNum,1);

for i = 1:clusterNum
    thisClusterPts = clusterPts{i};
    dataInfo(thisClusterPts,1) = dataInfo(thisClusterPts,1) + 1;
    dataInfo(thisClusterPts,2) = i;
    clusterCenter(i,:) = mean(data(thisClusterPts,:),1);
end

for i = 1:dataNum
    if dataInfo(i,1) == 1
        clusterLabel(i) = dataInfo(i,2);
    else
        pd2 = pdist2(data(i,:),clusterCenter);
        [minV,minI] = min(pd2);
        clusterLabel(i) = minI;
    end
end

Silhouette = sum(silhouette(data,clusterLabel)); 