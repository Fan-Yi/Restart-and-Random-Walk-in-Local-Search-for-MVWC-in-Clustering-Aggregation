function [wMWIS,MWIS] = MWIS_SA(weightList,adjMatrix,knownMIS)

q = 0.3;
n = 100;
beta = 0.999;

knownMIS = (knownMIS > 0);

cwList = adjMatrix * weightList - weightList;
iwdList = weightList ./ cwList;

numNode = numel(weightList);
numMIS = size(knownMIS,1);
maxW = zeros(numMIS,1);
maxM = zeros(numMIS,numNode);

for idxMIS = 1:numMIS
    idxMIS;
    thisMIS = knownMIS(idxMIS,:);
    
    thisIndicator = thisMIS;
    thisSumWeight = sum(weightList(thisIndicator));
    
    bestIndicator = thisIndicator;
    bestSumWeight = thisSumWeight;  
    
    for t = 1:n
        thisIdx = find(thisIndicator);
        wdList = iwdList(thisIndicator);
        remainNum = floor(sum(thisIndicator) * (1-q));        
        sampleIdx = sampleByWeight(wdList,remainNum);
        remainIdx = thisIdx(sampleIdx);
        
        nextIndicator = (thisIndicator == -1);
        nextIndicator(remainIdx) = 1;
        
        while 1
            compatibleIndicator = (nextIndicator * adjMatrix == 0);
            if sum(compatibleIndicator) == 0
                break;
            else
                compatibleIdx = find(compatibleIndicator);
                compatibleNum = numel(compatibleIdx);
                if compatibleNum == 1
                    nextIndicator(compatibleIdx) = 1;
                    break;
                else
                    wpList = weightList(compatibleIdx);
                    cwpList = wpList * 0;
                    for i = 1:compatibleNum
                        iIdx = compatibleIdx(i);
                        for j = i+1:compatibleNum
                            jIdx = compatibleIdx(j);
                            if adjMatrix(iIdx,jIdx) == 1
                                cwpList(i) = cwpList(i) + wpList(j);
                                cwpList(j) = cwpList(j) + wpList(i);
                            end
                        end
                    end
                    wdpList = wpList ./ cwpList;
                    [maxValue,maxIndex] = max(wdpList);
                    mcIdx = compatibleIdx(maxIndex);
                    nextIndicator(mcIdx) = 1;
                end
            end            
        end
        
        nextSumWeight = sum(weightList(nextIndicator));
        if nextSumWeight > thisSumWeight
            thisIndicator = nextIndicator;
            thisSumWeight = nextSumWeight;
            if nextSumWeight > bestSumWeight
                bestIndicator = nextIndicator;
                bestSumWeight = nextSumWeight;
            end
        else
            aRatio = exp((nextSumWeight - thisSumWeight) / (beta ^ t));
            if rand < aRatio
                thisIndicator = nextIndicator;
                thisSumWeight = nextSumWeight;
            end
        end
    end
    
    maxW(idxMIS) = bestSumWeight;
    maxM(idxMIS,:) = bestIndicator(:);
end

[wMWIS,iMWIS] = max(maxW);
MWIS = maxM(iMWIS,:).';