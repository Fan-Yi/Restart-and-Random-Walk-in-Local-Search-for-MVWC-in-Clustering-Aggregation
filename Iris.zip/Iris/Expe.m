clear;

addpath('C:\Users\tuc34608\Dropbox\MWIS\MWC\Yi');
addpath('C:\Users\tuc34608\Dropbox\MWIS\MWC\fast-wclq');
load('data.mat');
load('LinkageClustering.mat');

testNum = 100;
tolerateRatio = 0.05;

dataNum = numel(label);
kNum = numel(kList);
lkClusterNum = numel(lkClusterSLE);
lkClusteringNum = numel(lkClusteringSLE);
kmClusterNum = sum(kList);

baseClustering = cell(testNum,1);
testResult = zeros(testNum,10);

for testIdx = 1:testNum
    testIdx   
    allClusterPts = cell(lkClusterNum + kmClusterNum,1);
    for i = 1:lkClusterNum
        allClusterPts{i} = lkClusterPts{i};
    end
    allClusterSLE = lkClusterSLE;
    allClustering = lkClustering;
    allClusteringSLE = lkClusteringSLE;
    allLedger = lkLedger;
    kmClusterIdx = 0;
    for i = 1:kNum
        k = kList(i);
        [IDX] = kmeans(data,k);
        SLE = silhouette(data,IDX);    
        allClustering = [allClustering,IDX];
        allClusteringSLE = [allClusteringSLE;sum(SLE)];
        for j = 1:k
            kmClusterIdx = kmClusterIdx + 1;
            thisClusterPts = find(IDX == j);
            allClusterPts{lkClusterNum + kmClusterIdx} = thisClusterPts;
            thisSLE = SLE(thisClusterPts);
            allClusterSLE = [allClusterSLE;sum(thisSLE)];
            allLedger = [allLedger;[i + lkClusteringNum,4]];
        end
    end
    
    allClusteringNum = numel(allClusteringSLE);
    allClusterNum = numel(allClusterSLE);
    knownMIS = zeros(allClusteringNum,allClusterNum);
    adjMatrix = eye(allClusterNum);

    for i = 1:allClusterNum
        thisClusteringIdx = allLedger(i,1);
        knownMIS(thisClusteringIdx,i) = 1;
        iPts = allClusterPts{i};
        iPtsNum = numel(iPts);
        for j = i+1:allClusterNum
            jPts = allClusterPts{j};
            jPtsNum = numel(jPts);
            interSet = intersect(iPts,jPts);
            interNum = double(numel(interSet));
            if interNum/min([iPtsNum,jPtsNum]) > tolerateRatio;
                adjMatrix(i,j) = 1;
                adjMatrix(j,i) = 1;
            end
        end
    end
    
    allClusterWeight = allClusterSLE;
    
    [wMWIS,MWIS] = MWIS_SA(allClusterWeight,adjMatrix,knownMIS);
    finalClusterIdx = find(MWIS);    
    finalClusterPts = allClusterPts(finalClusterIdx);
    [clusterLabel,Silhouette] = stitchCluster(finalClusterPts,data); 
    
    [maxClusteringSLE,maxClusteringIdx] = max(allClusteringSLE);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    npIdx = (allClusterWeight <= 0);
    allClusterWeight(npIdx) = 0;
    mwCAdjMatrix = adjMatrix;
    mwCAdjMatrix(npIdx,:) = 1;
    mwCAdjMatrix(:,npIdx) = 1;
    mwCAdjMatrix = 1 - mwCAdjMatrix;    
	
    v_num = allClusterNum;
    e_num = sum(mwCAdjMatrix(:)) / 2;
    seed = 1;
    time_limit = 30000;
    
    weight_list = [0;allClusterWeight];
    mwCAdjMatrix = [zeros(1,v_num+1);[zeros(v_num,1),mwCAdjMatrix]];
    
    yiMWC = yi(int32(mwCAdjMatrix(:)), weight_list, v_num, e_num, seed, time_limit);  
    yiClusterPts = allClusterPts(yiMWC);
    [yiLabel,yiSLE] = stitchCluster(yiClusterPts,data);
    
%     fastwclqMWC = fastwclq(int32(mwCAdjMatrix(:)), weight_list, v_num, e_num, seed, time_limit);  
%     fastwclqClusterPts = allClusterPts(fastwclqMWC);
%     [fastwclqLabel,fastwclqSLE] = stitchCluster(fastwclqClusterPts,data);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    testResult(testIdx,1) = NMImax(clusterLabel,label);
    testResult(testIdx,2) = NMImax(allClustering(:,maxClusteringIdx),label);
    testResult(testIdx,3) = numel(finalClusterIdx);
    testResult(testIdx,4) = wMWIS;
    testResult(testIdx,5) = Silhouette;
    testResult(testIdx,6) = max(maxClusteringSLE);
    testResult(testIdx,7) = NMImax(yiLabel,label);
    testResult(testIdx,8) = sum(allClusterWeight(yiMWC));
%     testResult(testIdx,9) = NMImax(fastwclqLabel,label);
%     testResult(testIdx,10) = sum(allClusterWeight(fastwclqMWC));
    
    baseClustering{testIdx} = allClustering;
end

AAAResult = mean(testResult,1);

allBaseCls = baseClustering;
gt = label;
save('myResult.mat','allBaseCls','gt','testResult');